#import <React/RCTBridgeModule.h>

@interface EasebuzzKit : NSObject <RCTBridgeModule>

@end
